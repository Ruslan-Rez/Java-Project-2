package Project2;

class Baloon {
    private long number;
    private BaloonColor color;
    void setNumber(long number){
        this.number = number;
    }
    void setColor(BaloonColor color){
        this.color = color;
    }
}
