package Project2;

public enum BaloonColor { YELLOW, GREEN , BLUE , ORANGE , PURPLE , RED ,MAGENTA , PINK , TURQUOISE ,
    BLACK , MAROON , WHITE , LIME , PEACH , BROWN , GOLD}

